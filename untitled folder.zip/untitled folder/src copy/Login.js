import React, { useState } from 'react';
import './App.css';
import { useNavigate } from 'react-router-dom';

function Login() {
    const navigate = useNavigate();

    const FormExample = () => {
        const [formData, setFormData] = useState({
            username: '',
            password: '',
        });

        const [errors, setErrors] = useState({
            username: false,
            password: false,
        });

        const handleChange = (event) => {
            const { id, value } = event.target;
            setFormData((prevData) => ({
                ...prevData,
                [id]: value
            }));
            
            setErrors((prevErrors) => ({
                ...prevErrors,
                [id]: false
            }));
        };

        const handleSubmit = (event) => {
            event.preventDefault();

            const newErrors = {
                username: !formData.username,
                password: !formData.password,
            };

            setErrors(newErrors);

            const hasErrors = Object.values(newErrors).some(error => error);

            if (!hasErrors) {
                console.log('Form Data:', formData);
                navigate('/dashboard');
            }
        };

        return (
            <div className='body'>
                <div style={{height: '10%', marginTop:'5%'}}>
                    <h2>Login #07</h2>
                </div>
                <div className='main'>
                    <div className='right'>
                        <div style={{color:'white', marginTop:'35%'}}>
                            <h2>Welcome to login</h2> <br/>
                        </div>
                        <div style={{color:'white', fontSize:'13px'}}>
                            <p>Don't have an account?</p> <br/> 
                        </div>
                        <div>
                            <button style={{width:'20%', height:'40px', backgroundColor:'transparent',
                                borderColor:'white', borderRadius:'50px', color:'white'}}>
                                Sign Up
                            </button>
                        </div>
                    </div>
                    <div>
                        <form onSubmit={handleSubmit}>
                            <div style={{textAlign:'left', marginLeft:'55px', fontSize:'25px', 
                                marginTop:'50px'}}>
                                Sign In
                            </div>
                            <div style={{display:'flex', flexDirection:'column'}}>
                                <label className='label'><b>USERNAME</b></label>
                                <input type="text" id="username" placeholder="Username" 
                                    onChange={handleChange} value={formData.username} className='box'/>
                                {errors.username && (
                                    <p className='error'>Username is required</p>
                                )}
                            </div>

                            <div style={{display:'flex', flexDirection:'column'}}>
                                <label className='label'><b>PASSWORD</b></label>
                                <input type="password" id="password" placeholder="Password" 
                                    onChange={handleChange} value={formData.password} className='box'/>
                                {errors.password && (
                                    <p className='error'>Password is required</p>
                                )}
                            </div>
                            
                            <div style={{display:'flex', flexDirection:'column'}}>
                                <button 
                                    type='submit' id='submit' 
                                    style={{width: '80%', height: '40px', margin: '20px 0px 0px 50px',
                                        borderRadius:'40px', border:'none', backgroundColor:'#ff4767', 
                                        color:'white'}}>
                                    Log in
                                </button>
                            </div>

                            <div style={{display:'flex', gap:'50px'}}>
                                <div className='form-group'>
                                    <input type="checkbox" id="rememberMe"/>
                                    <label for="rememberMe" class="checkbox-label">Remember Me</label>
                                </div>
                                <div>
                                    <p class="forgot-password">Forgot Password</p>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div>
            <FormExample />
        </div>
    );
}

export default Login;
