import React, { useContext } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faStar } from '@fortawesome/fontawesome-free-solid'
import { ShopContext } from "./shopContext";

export const Product = (props) => {
    const { id, productName, category, price } = props.data;
    const { addToCart, cartItems } = useContext(ShopContext)
    const cartItemAmt = cartItems[id]
    return <div className="product">
        <img src="header.jpg" />
        <div><b>{productName}</b></div>
        <div style={{color:'grey'}}>{category}</div>
        <div>{price}</div>
        <div>
            <FontAwesomeIcon icon={faStar} />
            <FontAwesomeIcon icon={faStar} />
            <FontAwesomeIcon icon={faStar} />
            <FontAwesomeIcon icon={faStar} />
            <FontAwesomeIcon icon={faStar} />
        </div>
        <div>
            <button className="addtocart" onClick={() => addToCart(id)}>
                Add To Cart {cartItemAmt>0 && <>({cartItemAmt})</>}
            </button>
        </div>
    </div>
}