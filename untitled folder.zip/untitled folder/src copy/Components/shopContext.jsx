import React, { createContext, useState, useEffect } from 'react';
import { Product } from './product'; // Make sure the import path is correct
import { PRODUCTS } from './Products'; // Make sure the import path is correct

export const ShopContext = createContext(null);

const getDefaultCart = () => {
    let cart = {};
    for (let i = 1; i < PRODUCTS.length + 1; i++) {
        cart[i] = 0;
    }
    return cart;
};

export const ShopContextProvider = (props) => {
    const [cartItems, setCartItems] = useState(getDefaultCart);

    const addToCart = (id) => {
        setCartItems((prev) => ({ ...prev, [id]: prev[id] + 1 }));
    };

    const removeFromCart = (id) => {
        setCartItems((prev) => {
            const newCartItems = { ...prev };
            if (newCartItems[id] > 0) {
                newCartItems[id] -= 1;
            }
            return newCartItems;
        });
    };

    const contextValue = { cartItems, addToCart, removeFromCart };

    useEffect(() => {
        console.log(cartItems);
    }, [cartItems]);

    return (
        <ShopContext.Provider value={contextValue}>
            {props.children}
        </ShopContext.Provider>
    );
};
