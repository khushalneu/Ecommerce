import React from 'react';
import './MainContent.css';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faShoppingCart, faStar } from '@fortawesome/fontawesome-free-solid'
import {PRODUCTS} from "./Products"
import {Product} from "./product"

const MainContent = () => {
    const navigate = useNavigate(); 

    const handleSubmit = (event) => {
        event.preventDefault(); 
        navigate('/cart');
    }
  return (
    <div className='page'>
        <div className='container'>
            <div className='header'>
                <div className='hbox' style={{fontSize:'30px', paddingTop:'1.5%', 
                    paddingLeft:'2%', width:'130px'}}>DNK</div>
                <div className='hbox' style={{width:'110px'}}>EVERYTHING</div>
                <div className='hbox' style={{width:'80px'}}>WOMEN</div>
                <div className='hbox' style={{width:'60px'}}>MEN</div>
                <div className='hbox' style={{width:'40px'}}>ACCESSORIES</div>
                <div className='hbox' style={{width:'500px'}}></div>
                <div className='hbox' style={{width:'70px'}}>ABOUT</div>
                <div className='hbox' style={{width:'110px'}}>CONTACT US</div>
                <div className='hbox' style={{width:'50px'}}>$0.00</div>
                <div className='hbox' style={{width:'20px'}}>
                    <button onClick={handleSubmit}><FontAwesomeIcon icon={faShoppingCart} /></button>
                </div>
            </div>
            <div className='content'>
                <h1 style={{fontSize:'60px'}}>Raining Offers For <br/> Hot Summer!</h1> <br/> <br/>
                <h3 style={{fontSize:'25px'}}>25% Off On All Products</h3> <br/> <br/>
                <button className='shopnow'><b>SHOP NOW</b></button>
                <button className='findmore'><b>FIND MORE</b></button>
            </div>
            <div className='himg'>
                <img src='header.jpg' style={{height:'73vh', width:'90%', marginLeft:'10%'}}></img>
            </div>
        </div>
        <div className='logos'>
            <div className='lbox'></div>
            <div className='lbox'>logoipsum</div>
            <div className='lbox'>logoipsum</div>
            <div className='lbox'>logoipsum</div>
            <div className='lbox'>logoipsum</div>
            <div className='lbox'>logoipsum</div>
            <div className='lbox'></div>
        </div>
        <div className='images'>
            <div className='imagebox' style={{marginLeft:'5%'}}>
                <img src='header.jpg' style={{height:'100%', width:'100%'}}/>
            </div>
            <div className='imagebox' style={{marginLeft:'3%'}}>
                <img src='header.jpg' style={{height:'100%', width:'100%'}}/>
            </div>
            <div className='imagebox' style={{marginLeft:'3%'}}>
                <img src='header.jpg' style={{height:'100%', width:'100%'}}/>
            </div>
        </div>
        <div className='featured'>
            <div className='header2'>
                <h1>Featured Products</h1> <br/>
            </div>
            <div className='products'>
                {PRODUCTS.map((product) => <Product data={product}/>)}
                <div style={{width:'2.5%'}}></div>
            </div>
            <div className='content2'>
                <div className='info'>
                    <h3>Limited Time Offer</h3> <br/>
                    <h1 style={{fontSize:'40px'}}>Special Edition</h1> <br/>
                    <p>abcd efg hijk lmno pqrs tuv wxyz abcd efg hijk lmno pqrs tuv wxyz abcd efg hijk <br/> <br/>
                    lmno pqrs tuv wxyz abcd efg hijk</p> <br/>
                    <h3>Buy this T-shirt at 20% Discount, Use Code OFF20</h3> <br/> <br/>
                    <button className='shopnow'><b>SHOP NOW</b></button>
                </div>
                <div>
                    <img src='header.jpg' className='shopping'></img>
                </div>
            </div>
        </div>
    </div>
 );
};

export default MainContent;