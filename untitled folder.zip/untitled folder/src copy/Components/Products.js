export const PRODUCTS= [
    {
        id: 1,
        productName: 'DNK Yellow Shoes',
        category: 'Men',
        price: 120.00
    },
    {
        id: 2,
        productName: 'DNK Blue Shoes',
        category: 'Men',
        price: 200.00
    },
    {
        id: 3,
        productName: 'Dark Brown Jeans',
        category: 'Men',
        price: 150.00
    },
    {
        id: 4,
        productName: 'Blue Denim Jeans',
        category: 'Women',
        price: 150.00
    },
    {
        id: 5,
        productName: 'Basic Grey Jeans',
        category: 'Women',
        price: 150.00
    }
]