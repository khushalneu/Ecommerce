import React from 'react';
import './App.css';
import Login from './Login';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import MainContent from './Components/MainContent';
import { ShopContextProvider } from './Components/shopContext';
import CartItem from './Cart/cart-item';
import Cart from './Cart/cart'; // Import the Cart component

function App() {
  return (
    <div className="App">
      <ShopContextProvider>
        <Router>
          <Routes>
            <Route path='/' element={<Login />} />
            <Route path='/dashboard' element={<MainContent />} />
            <Route path='/cart' element={<Cart />} />
          </Routes>
        </Router>
      </ShopContextProvider>
    </div>
  );
}

export default App;
