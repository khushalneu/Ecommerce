import React from 'react';

export const CartItem = (props) => {
    const { id, productName, category, price } = props.data;
    return (
      <div className='cartItem'>
        <img src='header.jpg' />
        <p>
            {" "}
            <b> {productName} </b>
        </p>
        <p> ${price} </p>
      </div>
    );
};

export default CartItem;
