import React, { useEffect, useState } from 'react';
import './App.css';

function Signup() {

    useEffect(() => {
        fetchitems();
    }, []);

    const [items, setItems] = useState([]);
    
    const fetchitems = async () => {
        console.log('123')
        const data = await fetch('https://api.apis.guru/v2/list.json');
        console.log(data);

        const items = await data.json();
        console.log(items['zuora.com'].added);
        setItems(items['zuora.com'].added);
    }

    return (
        <div>
            <h1>{items}</h1>
        </div>
  );
}

export default Signup;
